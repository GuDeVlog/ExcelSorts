#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <string>
#include <stdexcept>
#include <algorithm>
#include <chrono>
#include <cmath>
#include <iomanip>
#include <ctime>
using namespace std;
using namespace std::chrono;

class Pessoa {
public:
    string nome;
    int idade;
    double peso;
    double altura;
    Pessoa() {}
    Pessoa(string _nome, int _idade, double _peso, double _altura) : nome(_nome), idade(_idade), peso(_peso), altura(_altura) {}
};

class LeitorCSV {
public:
    static vector<Pessoa> lerCSV(const string& arquivo) {
        vector<Pessoa> pessoas;
        ifstream file(arquivo);
        if (!file.is_open()) {
            cerr << "Erro ao abrir o arquivo " << arquivo << endl;
            return pessoas;
        }

        string linha;
        getline(file, linha);
        while (getline(file, linha)) {
            stringstream ss(linha);
            string nome, dataNascimento, peso, altura;
            getline(ss, nome, ';');
            getline(ss, dataNascimento, ';');
            getline(ss, peso, ';');
            getline(ss, altura, ',');

            int idade = calcularIdade(dataNascimento);

            try {
                pessoas.push_back(Pessoa(nome, idade, stod(peso), stod(altura)));
            }
            catch (const invalid_argument& e) {
                cerr << "Erro ao converter dados: " << e.what() << endl;
            }
        }
        file.close();
        return pessoas;
    }

private:
    static int calcularIdade(const string& dataNascimentoStr) {
        struct tm dataNascimento = {};
        stringstream ss(dataNascimentoStr);
        ss >> get_time(&dataNascimento, "%d/%m/%Y");

        time_t agora = time(nullptr);
        struct tm hoje = {};
        localtime_s(&hoje, &agora);

        int idade = hoje.tm_year - dataNascimento.tm_year;
        if (hoje.tm_mon < dataNascimento.tm_mon || (hoje.tm_mon == dataNascimento.tm_mon && hoje.tm_mday < dataNascimento.tm_mday)) {
            idade--;
        }

        return idade;
    }
};

class Ordenacao {
public:
    static void bubbleSort(vector<Pessoa>& pessoas) {
        int n = pessoas.size();
        for (int i = 0; i < n - 1; ++i) {
            for (int j = 0; j < n - i - 1; ++j) {
                if (pessoas[j].idade > pessoas[j + 1].idade) {
                    swap(pessoas[j], pessoas[j + 1]);
                }
            }
        }
    }

    static void insertionSort(vector<Pessoa>& pessoas) {
        int n = pessoas.size();
        for (int i = 1; i < n; ++i) {
            Pessoa key = pessoas[i];
            int j = i - 1;
            while (j >= 0 && pessoas[j].peso > key.peso) {
                pessoas[j + 1] = pessoas[j];
                j = j - 1;
            }
            pessoas[j + 1] = key;
        }
    }

    static void selectionSort(vector<Pessoa>& pessoas) {
        int n = pessoas.size();
        for (int i = 0; i < n - 1; ++i) {
            int min_idx = i;
            for (int j = i + 1; j < n; ++j) {
                if (pessoas[j].altura < pessoas[min_idx].altura) {
                    min_idx = j;
                }
            }
            swap(pessoas[min_idx], pessoas[i]);
        }
    }

    static void mergeSort(vector<Pessoa>& pessoas, int left, int right) {
        if (left < right) {
            int mid = left + (right - left) / 2;
            mergeSort(pessoas, left, mid);
            mergeSort(pessoas, mid + 1, right);
            merge(pessoas, left, mid, right);
        }
    }

    static void merge(vector<Pessoa>& pessoas, int left, int mid, int right) {
        int n1 = mid - left + 1;
        int n2 = right - mid;

        vector<Pessoa> L(n1), R(n2);

        for (int i = 0; i < n1; ++i)
            L[i] = pessoas[left + i];
        for (int j = 0; j < n2; ++j)
            R[j] = pessoas[mid + 1 + j];

        int i = 0, j = 0, k = left;
        while (i < n1 && j < n2) {
            if (L[i].nome <= R[j].nome) {
                pessoas[k] = L[i];
                ++i;
            }
            else {
                pessoas[k] = R[j];
                ++j;
            }
            ++k;
        }

        while (i < n1) {
            pessoas[k] = L[i];
            ++i;
            ++k;
        }

        while (j < n2) {
            pessoas[k] = R[j];
            ++j;
            ++k;
        }
    }

    static void quickSort(vector<Pessoa>& pessoas, int low, int high) {
        if (low < high) {
            int pi = partition(pessoas, low, high);
            quickSort(pessoas, low, pi - 1);
            quickSort(pessoas, pi + 1, high);
        }
    }

    static int partition(vector<Pessoa>& pessoas, int low, int high) {
        Pessoa pivot = pessoas[high];
        int i = low - 1;

        for (int j = low; j < high; ++j) {
            if (pessoas[j].idade < pivot.idade) {
                ++i;
                swap(pessoas[i], pessoas[j]);
            }
        }

        swap(pessoas[i + 1], pessoas[high]);
        return i + 1;
    }
};

double calcularMedia(const vector<double>& valores) {
    double soma = 0.0;
    for (double valor : valores) {
        soma += valor;
    }
    return soma / valores.size();
}

double calcularMediana(const vector<double>& valores) {
    int n = valores.size();
    if (n % 2 == 0) {
        return (valores[n / 2 - 1] + valores[n / 2]) / 2.0;
    }
    else {
        return valores[n / 2];
    }
}

double calcularDesvioPadrao(const vector<double>& valores) {
    double media = calcularMedia(valores);
    double somaQuadrados = 0.0;
    for (double valor : valores) {
        somaQuadrados += pow(valor - media, 2);
    }
    double variancia = somaQuadrados / valores.size();
    return sqrt(variancia);
}

void exibirListaCSV(const vector<Pessoa>& pessoas) {
    cout << "Lista CSV:\n";
    for (const auto& pessoa : pessoas) {
        cout << pessoa.nome << ", " << pessoa.idade << ", " << pessoa.peso << ", " << pessoa.altura << "\n";
    }
    cout << endl;
}

int main() {
    string arquivo_csv = "C:\\Users\\Testwork\\Desktop\\Trabalhos\\EC4\\Israel\\Vstudios\\dados_pessoais.csv";
    vector<Pessoa> pessoas = LeitorCSV::lerCSV(arquivo_csv);
    cout << "Total de pessoas lidas: " << pessoas.size() << endl;

    vector<Pessoa> pessoasBubble = pessoas;
    cout << "Bubble Sort em execucao...\n";
    auto start = high_resolution_clock::now();
    Ordenacao::bubbleSort(pessoasBubble);
    auto stop = high_resolution_clock::now();
    auto duration_bubble = duration_cast<microseconds>(stop - start);
    cout << "Tempo de execução do Bubble Sort: " << fixed << setprecision(6) << duration_bubble.count() / 1000000.0 << " segundos\n";
    exibirListaCSV(pessoasBubble);

    vector<Pessoa> pessoasInsertion = pessoas;
    cout << "Insertion Sort em execucao...\n";
    start = high_resolution_clock::now();
    Ordenacao::insertionSort(pessoasInsertion);
    stop = high_resolution_clock::now();
    auto duration_insertion = duration_cast<microseconds>(stop - start);
    cout << "Tempo de execução do Insertion Sort: " << fixed << setprecision(6) << duration_insertion.count() / 1000000.0 << " segundos\n";
    exibirListaCSV(pessoasInsertion);

    vector<Pessoa> pessoasQuick = pessoas;
    cout << "Quick Sort em execucao...\n";
    start = high_resolution_clock::now();
    Ordenacao::quickSort(pessoasQuick, 0, pessoasQuick.size() - 1);
    stop = high_resolution_clock::now();
    auto duration_quick = duration_cast<microseconds>(stop - start);
    cout << "Tempo de execução do Quick Sort: " << fixed << setprecision(6) << duration_quick.count() / 1000000.0 << " segundos\n";
    exibirListaCSV(pessoasQuick);

    vector<Pessoa> pessoasSelection = pessoas;
    cout << "Selection Sort em execucao...\n";
    start = high_resolution_clock::now();
    Ordenacao::selectionSort(pessoasSelection);
    stop = high_resolution_clock::now();
    auto duration_selection = duration_cast<microseconds>(stop - start);
    cout << "Tempo de execução do Selection Sort: " << fixed << setprecision(6) << duration_selection.count() / 1000000.0 << " segundos\n";
    exibirListaCSV(pessoasSelection);

    vector<Pessoa> pessoasMerge = pessoas;
    cout << "Merge Sort em execucao...\n";
    start = high_resolution_clock::now();
    Ordenacao::mergeSort(pessoasMerge, 0, pessoasMerge.size() - 1);
    stop = high_resolution_clock::now();
    auto duration_merge = duration_cast<microseconds>(stop - start);
    cout << "Tempo de execução do Merge Sort: " << fixed << setprecision(6) << duration_merge.count() / 1000000.0 << " segundos\n";
    exibirListaCSV(pessoasMerge);

    cout << "\nEstatisticas ---------------------------------------" << endl;
    vector<double> idades, pesos, alturas;
    for (const auto& pessoa : pessoas) {
        idades.push_back(pessoa.idade);
        pesos.push_back(pessoa.peso);
        alturas.push_back(pessoa.altura);
    }

    sort(idades.begin(), idades.end());
    double mediaIdades = calcularMedia(idades);
    double medianaIdades = calcularMediana(idades);
    double desvioPadraoIdades = calcularDesvioPadrao(idades);
    double mediaPesos = calcularMedia(pesos);
    double medianaPesos = calcularMediana(pesos);
    double desvioPadraoPesos = calcularDesvioPadrao(pesos);
    double mediaAlturas = calcularMedia(alturas);
    double medianaAlturas = calcularMediana(alturas);
    double desvioPadraoAlturas = calcularDesvioPadrao(alturas);

    cout << "Media das idades: " << mediaIdades << " anos" << endl;
    cout << "Mediana das idades: " << medianaIdades << " anos" << endl;
    cout << "Desvio padrão das idades: " << desvioPadraoIdades << " anos" << endl;
    cout << "--------------------------------------- " << endl;
    cout << "Media dos pesos: " << mediaPesos << " kg" << endl;
    cout << "Mediana dos pesos: " << medianaPesos << " kg" << endl;
    cout << "Desvio padrão dos pesos: " << desvioPadraoPesos << " kg" << endl;
    cout << "--------------------------------------- " << endl;
    cout << "Media das alturas: " << mediaAlturas << " m" << endl;
    cout << "Mediana das alturas: " << medianaAlturas << " m" << endl;
    cout << "Desvio padrão das alturas: " << desvioPadraoAlturas << " m" << endl;
    cout << "--------------------------------------- " << endl;

    cout << "\nTempo de execucao dos algoritmos de ordenacao:\n";
    cout << "Bubble Sort: " << duration_bubble.count() / 1000000.0 << " segundos\n";
    cout << "Insertion Sort: " << duration_insertion.count() / 1000000.0 << " segundos\n";
    cout << "Selection Sort: " << duration_selection.count() / 1000000.0 << " segundos\n";
    cout << "Merge Sort: " << duration_merge.count() / 1000000.0 << " segundos\n";
    cout << "Quick Sort: " << duration_quick.count() / 1000000.0 << " segundos\n";

    return 0;
}